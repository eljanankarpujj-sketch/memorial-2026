create table if not exists candles (
  id uuid default uuid_generate_v4() primary key,
  honoree_name text,
  user_name text,
  message text,
  created_at timestamp default now()
);